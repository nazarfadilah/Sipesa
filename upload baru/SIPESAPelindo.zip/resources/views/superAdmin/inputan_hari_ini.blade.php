@extends('superAdmin.layout')

@section('title', 'Inputan Hari Ini')

@section('content')
<div class="container-fluid px-4 py-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <div style="background-color: #1E3F8C" class="p-4 rounded-top">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="text-white mb-0">Inputan Hari Ini</h4>
                        <small class="text-white-50">Tanggal: {{ now()->translatedFormat('l, d F Y') }}</small>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="row text-white">
                            <div class="col-6">
                                <div class="fw-bold">Sampah Terkelola</div>
                                <div class="fs-5">{{ number_format($totalTerkelola, 2) }} kg</div>
                            </div>
                            <div class="col-6">
                                <div class="fw-bold">Sampah Diserahkan</div>
                                <div class="fs-5">{{ number_format($totalDiserahkan, 2) }} kg</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white p-4 rounded-bottom shadow">
                <div class="table-responsive">
                    <table id="inputanHariIniTable" class="table table-striped table-bordered w-100">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th class="text-center" width="4%">No</th>
                                <th class="text-center" width="8%">Tipe</th>
                                <th class="text-center" width="12%">User</th>
                                <th class="text-center" width="12%">Instansi</th>
                                <th class="text-center" width="12%">Jenis</th>
                                <th class="text-center" width="12%">Sumber</th>
                                <th class="text-center" width="8%">Berat (kg)</th>
                                <th class="text-center" width="12%">Tujuan</th>
                                <th class="text-center" width="10%">Foto</th>
                                <th class="text-center" width="10%">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($allData as $index => $item)
                            <tr>
                                <td class="text-center">{{ $index + 1 }}</td>

                                <td class="text-center">
                                    @if ($item->tipe === 'terkelola')
                                        <span class="badge" style="background-color: #28a745;">Terkelola</span>
                                    @else
                                        <span class="badge" style="background-color: #007bff;">Diserahkan</span>
                                    @endif
                                </td>

                                <td>{{ $item->user->name ?? '-' }}</td>

                                <td>{{ $item->user->instansi->nama_instansi ?? '-' }}</td>

                                <td>{{ $item->jenis->nama_jenis ?? '-' }}</td>

                                <td>{{ $item->lokasiAsal->nama_lokasi ?? '-' }}</td>

                                <td class="text-center">{{ number_format($item->jumlah_berat, 2) }}</td>

                                <td>{{ $item->tujuan_display }}</td>

                                <td class="text-center">
                                    @if ($item->tipe === 'terkelola')
                                        @if ($item->foto_kelola)
                                            <a href="{{ asset($item->foto_kelola) }}" target="_blank" class="btn btn-sm btn-light">
                                                <i class="fas fa-image"></i> Lihat
                                            </a>
                                        @else
                                            <span class="text-muted">-</span>
                                        @endif
                                    @else
                                        @if ($item->foto_diserahkan)
                                            <a href="{{ asset($item->foto_diserahkan) }}" target="_blank" class="btn btn-sm btn-light">
                                                <i class="fas fa-image"></i> Lihat
                                            </a>
                                        @else
                                            <span class="text-muted">-</span>
                                        @endif
                                    @endif
                                </td>

                                <td class="text-center">
                                    @if ($item->tipe === 'terkelola')
                                        {{ \Carbon\Carbon::parse($item->tgl)->format('d-m-Y') }}
                                    @else
                                        {{ \Carbon\Carbon::parse($item->tgl_diserahkan)->format('d-m-Y') }}
                                    @endif
                                </td>
                            </tr>

                            @empty
                            <tr>
                                <td colspan="10" class="text-center">Tidak ada data inputan hari ini</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
$(document).ready(function() {
    // Initialize DataTable
    var table = $('#inputanHariIniTable').DataTable({
        destroy: true,
        responsive: true,
        pageLength: 10,
        lengthMenu: [[5, 10, 25, 50, 100], [5, 10, 25, 50, 100]],
        pagingType: "simple_numbers",
        paging: true,
        info: true,
        searching: true,
        language: {
            search: "Cari:",
            lengthMenu: "_MENU_",
            zeroRecords: "Tidak ditemukan data yang sesuai",
            paginate: {
                first: "Awal",
                last: "Akhir",
                next: "Selanjutnya",
                previous: "Sebelumnya"
            }
        },
        columnDefs: [
            { orderable: false, targets: [1, 8] } // Tipe dan Foto tidak bisa di-sort
        ]
    });
});
</script>
@endpush

@endsection
